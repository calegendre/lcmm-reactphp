// LCMM Configuration
window.LCMM_CONFIG = {
  apiBaseUrl: 'https://lcmm.legendre.cloud/api'
};