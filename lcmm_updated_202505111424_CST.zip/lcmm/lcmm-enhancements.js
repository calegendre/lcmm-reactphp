// LCMM enhancements

// Function to add logo to header
function addLogoToHeader() {
    // Find all header containers with the LCMM text
    const headerContainers = document.querySelectorAll('nav .flex .flex-shrink-0 h1, nav .flex .flex-shrink-0 span');
    
    headerContainers.forEach(container => {
        // Don't add logo if it already exists
        if (container.parentElement.querySelector('.logo-container')) {
            return;
        }
        
        // Create container for logo and text that keeps them side by side
        const flexContainer = document.createElement('div');
        flexContainer.className = 'flex items-center logo-text-container';
        
        // Create logo container
        const logoContainer = document.createElement('div');
        logoContainer.className = 'logo-container mr-2';
        
        const logo = document.createElement('img');
        logo.src = '/logo.png';
        logo.alt = 'LCMM Logo';
        logo.style.height = '32px';
        
        logoContainer.appendChild(logo);
        
        // Move the existing text to the flex container
        const parent = container.parentElement;
        const text = container;
        
        // Remove existing text from parent
        parent.removeChild(text);
        
        // Add logo and text to flex container
        flexContainer.appendChild(logoContainer);
        flexContainer.appendChild(text);
        
        // Add flex container to parent
        parent.appendChild(flexContainer);
    });
}

// Function to add logo to login/signup page
function addLogoToLoginPage() {
    // More comprehensive selector for login forms
    const loginContainers = document.querySelectorAll('.login-container, .signup-container');
    
    loginContainers.forEach(container => {
        if (!container.querySelector('.login-logo')) {
            const form = container.querySelector('form');
            
            if (form) {
                const logo = document.createElement('img');
                logo.src = '/logo.png';
                logo.alt = 'LCMM Logo';
                logo.className = 'login-logo';
                
                container.insertBefore(logo, form);
                
                // Log for debugging
                console.log('Added logo to login/signup page');
            }
        }
    });
    
    // Fallback for login form without specific container class
    const standaloneForms = document.querySelectorAll('form.mt-8.space-y-6');
    
    standaloneForms.forEach(form => {
        if (!form.parentElement.querySelector('.login-logo')) {
            const logo = document.createElement('img');
            logo.src = '/logo.png';
            logo.alt = 'LCMM Logo';
            logo.className = 'login-logo';
            
            form.parentElement.insertBefore(logo, form);
            
            // Log for debugging
            console.log('Added logo to standalone login form');
        }
    });
}

// Function to handle missing cover images
function handleMissingImages() {
    const mediaImages = document.querySelectorAll('.media-card img, .cover-art img');
    
    mediaImages.forEach(img => {
        img.onerror = function() {
            this.src = '/coverunavailable.png';
            this.onerror = null; // Prevent infinite loop if placeholder is also missing
        };
    });
}

// Function to enhance activity logs with filtering
function enhanceActivityLogs() {
    // Look for the activity logs container using different selectors to ensure we find it
    let activityLogsContainer = null;
    
    // Try by id first
    activityLogsContainer = document.getElementById('activity-logs-container');
    
    // Try by finding heading text
    if (!activityLogsContainer) {
        const headings = Array.from(document.querySelectorAll('h1, h2, h3'));
        for (const heading of headings) {
            if (heading.textContent.includes('Activity Log')) {
                activityLogsContainer = heading.parentElement;
                break;
            }
        }
    }
    
    // Try to find by table class
    if (!activityLogsContainer) {
        activityLogsContainer = document.querySelector('table.admin-table');
    }
    
    // Try by any table in admin section
    if (!activityLogsContainer) {
        activityLogsContainer = document.querySelector('.admin-content table');
    }
    
    if (activityLogsContainer) {
        console.log("Found activity logs container:", activityLogsContainer);
        
        // Check if filters already exist
        if (!document.querySelector('.activity-filters')) {
            console.log("Creating activity filters...");
            
            // Create filter container
            const filterContainer = document.createElement('div');
            filterContainer.className = 'activity-filters';
            filterContainer.style.display = 'flex';
            filterContainer.style.gap = '1rem';
            filterContainer.style.marginBottom = '1rem';
            filterContainer.style.flexWrap = 'wrap';
            
            // User filter
            const userFilter = document.createElement('select');
            userFilter.id = 'user-filter';
            userFilter.style.padding = '0.5rem';
            userFilter.style.borderRadius = '0.375rem';
            userFilter.style.backgroundColor = '#2d2d2d';
            userFilter.style.border = '1px solid #3e3e3e';
            userFilter.style.color = 'white';
            userFilter.innerHTML = '<option value="all">All Users</option>';
            
            // Add users from the table if available
            const users = new Map();
            document.querySelectorAll('table tbody tr td:nth-child(2)').forEach(cell => {
                const email = cell.textContent.trim();
                if (email && !users.has(email)) {
                    users.set(email, true);
                    const option = document.createElement('option');
                    option.value = email;
                    option.textContent = email;
                    userFilter.appendChild(option);
                }
            });
            
            // Action filter
            const actionFilter = document.createElement('select');
            actionFilter.id = 'action-filter';
            actionFilter.style.padding = '0.5rem';
            actionFilter.style.borderRadius = '0.375rem';
            actionFilter.style.backgroundColor = '#2d2d2d';
            actionFilter.style.border = '1px solid #3e3e3e';
            actionFilter.style.color = 'white';
            actionFilter.innerHTML = '<option value="all">All Actions</option>';
            
            // Get all unique actions from the table
            const actions = new Map();
            document.querySelectorAll('table tbody tr td:nth-child(3)').forEach(cell => {
                const action = cell.textContent.trim();
                if (action && !actions.has(action)) {
                    actions.set(action, true);
                    const option = document.createElement('option');
                    option.value = action;
                    option.textContent = action;
                    actionFilter.appendChild(option);
                }
            });
            
            // Sort order filter
            const sortOrder = document.createElement('select');
            sortOrder.id = 'sort-order';
            sortOrder.style.padding = '0.5rem';
            sortOrder.style.borderRadius = '0.375rem';
            sortOrder.style.backgroundColor = '#2d2d2d';
            sortOrder.style.border = '1px solid #3e3e3e';
            sortOrder.style.color = 'white';
            sortOrder.innerHTML = `
                <option value="desc">Newest First</option>
                <option value="asc">Oldest First</option>
            `;
            
            // Apply button
            const applyButton = document.createElement('button');
            applyButton.textContent = 'Apply Filters';
            applyButton.style.padding = '0.5rem';
            applyButton.style.borderRadius = '0.375rem';
            applyButton.style.backgroundColor = '#4f46e5';
            applyButton.style.borderColor = '#4338ca';
            applyButton.style.color = 'white';
            applyButton.style.cursor = 'pointer';
            applyButton.addEventListener('click', function() {
                const selectedAction = actionFilter.value;
                const selectedOrder = sortOrder.value;
                const selectedUser = userFilter.value;
                
                console.log("Applying filters:", {
                    action: selectedAction,
                    order: selectedOrder,
                    user: selectedUser
                });
                
                // Call API with filters
                fetchActivityLogs(selectedUser, selectedAction, selectedOrder);
            });
            
            applyButton.addEventListener('mouseover', function() {
                this.style.backgroundColor = '#4338ca';
            });
            
            applyButton.addEventListener('mouseout', function() {
                this.style.backgroundColor = '#4f46e5';
            });
            
            // Add to filter container
            filterContainer.appendChild(userFilter);
            filterContainer.appendChild(actionFilter);
            filterContainer.appendChild(sortOrder);
            filterContainer.appendChild(applyButton);
            
            // Insert before table
            activityLogsContainer.parentNode.insertBefore(filterContainer, activityLogsContainer);
            
            console.log("Activity filters created successfully");
        }
    } else {
        console.log("Activity logs container not found, will try again later");
        
        // Try again after a short delay to catch dynamically loaded content
        setTimeout(enhanceActivityLogs, 1000);
    }
}

// Function to fetch activity logs with filters
function fetchActivityLogs(userId = 'all', actionType = 'all', sortOrder = 'desc') {
    // Get authentication token
    const token = localStorage.getItem('lcmm_token');
    
    if (!token) {
        console.error('No authentication token found');
        return;
    }
    
    // Build query string
    let queryString = '?';
    if (userId !== 'all') queryString += `user_id=${userId}&`;
    if (actionType !== 'all') queryString += `action_type=${actionType}&`;
    queryString += `sort=${sortOrder}`;
    
    // Make API request
    fetch(`${window.LCMM_CONFIG.apiBaseUrl}/activity_logs.php${queryString}`, {
        method: 'GET',
        headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
        }
    })
    .then(response => response.json())
    .then(data => {
        // Update activity logs table
        updateActivityLogsTable(data.logs);
        
        // Update action filter if we have action types
        if (data.action_types && data.action_types.length > 0) {
            const actionFilter = document.getElementById('action-filter');
            if (actionFilter) {
                // Keep the "All Actions" option
                actionFilter.innerHTML = '<option value="all">All Actions</option>';
                
                // Add options for each action type
                data.action_types.forEach(action => {
                    const option = document.createElement('option');
                    option.value = action;
                    option.textContent = action;
                    if (action === actionType) {
                        option.selected = true;
                    }
                    actionFilter.appendChild(option);
                });
            }
        }
    })
    .catch(error => {
        console.error('Error fetching activity logs:', error);
    });
}

// Function to update activity logs table
function updateActivityLogsTable(logs) {
    const tableBody = document.querySelector('#activity-logs-container table tbody');
    
    if (tableBody) {
        // Clear existing rows
        tableBody.innerHTML = '';
        
        // Add new rows
        logs.forEach(log => {
            const row = document.createElement('tr');
            
            row.innerHTML = `
                <td>${new Date(log.created_at).toLocaleString()}</td>
                <td>${log.user_email}</td>
                <td>${log.action}</td>
                <td>${log.details}</td>
                <td>${log.ip_address}</td>
            `;
            
            tableBody.appendChild(row);
        });
    }
}

// Function to make header sticky
function setupStickyHeader() {
    const header = document.querySelector('nav.bg-dark-100');
    
    if (header) {
        document.addEventListener('scroll', function() {
            if (window.scrollY > 10) {
                header.classList.add('scrolled');
            } else {
                header.classList.remove('scrolled');
            }
        });
    }
}

// Initialize all enhancements when the page loads
document.addEventListener('DOMContentLoaded', function() {
    runEnhancements();
    
    // Set interval to periodically check for dynamically loaded content
    setInterval(runEnhancements, 1000);
});

// Function to run all enhancements
function runEnhancements() {
    addLogoToHeader();
    addLogoToLoginPage();
    handleMissingImages();
    enhanceActivityLogs();
    setupStickyHeader();
}

// Also run these functions when route changes (SPA navigation)
const originalPushState = history.pushState;
history.pushState = function() {
    originalPushState.apply(this, arguments);
    setTimeout(runEnhancements, 100);
};