<?php
$password = "X9k#vP2\$mL8qZ3nT";
$hash = password_hash($password, PASSWORD_DEFAULT);
echo "Original password: $password\n";
echo "Generated hash: $hash\n";
echo "Verification result: " . (password_verify($password, $hash) ? "true" : "false") . "\n";

// Test with our stored hash
$stored_hash = '$2y$10$eDGzXpE/yS88cAsrdYypGuuAVsPB8rVmdSBrppSYaj0EW5T45TwGS';
echo "Stored hash: $stored_hash\n";
echo "Verification with stored hash: " . (password_verify($password, $stored_hash) ? "true" : "false") . "\n";
?>