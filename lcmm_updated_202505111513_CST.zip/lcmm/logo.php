<?php
// Create a simple logo image
header('Content-Type: image/png');
$im = imagecreatetruecolor(180, 60);
$bg = imagecolorallocate($im, 41, 128, 185);
$textcolor = imagecolorallocate($im, 255, 255, 255);
imagefill($im, 0, 0, $bg);
imagestring($im, 5, 60, 20, 'LCMM', $textcolor);
imagepng($im);
imagedestroy($im);
?>