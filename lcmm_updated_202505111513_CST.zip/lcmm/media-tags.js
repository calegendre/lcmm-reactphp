// LCMM Media Status Tags

/**
 * Adds status tags to media cards for TV shows and movies
 * This script looks for media cards and adds appropriate status tags
 * based on the episodeStatus or downloadStatus properties
 */

document.addEventListener('DOMContentLoaded', function() {
    // Initial setup
    addMediaStatusTags();
    
    // Set up observer for dynamic content changes
    setupMutationObserver();
});

/**
 * Sets up a mutation observer to watch for changes in the DOM
 * This ensures tags are added to dynamically loaded content
 */
function setupMutationObserver() {
    const observer = new MutationObserver(function(mutations) {
        mutations.forEach(function(mutation) {
            if (mutation.addedNodes.length > 0) {
                // Check if any new nodes contain media cards
                mutation.addedNodes.forEach(function(node) {
                    if (node.nodeType === 1) { // Element node
                        // If this is a media card or contains media cards
                        if (node.classList && node.classList.contains('media-card')) {
                            processMediaCard(node);
                        } else if (node.querySelectorAll) {
                            const mediaCards = node.querySelectorAll('.media-card');
                            mediaCards.forEach(processMediaCard);
                        }
                    }
                });
            }
        });
    });
    
    // Start observing the document with the configured parameters
    observer.observe(document.body, { childList: true, subtree: true });
}

/**
 * Finds all media cards and adds status tags
 */
function addMediaStatusTags() {
    // Process all media cards in the document
    const mediaCards = document.querySelectorAll('.media-card');
    mediaCards.forEach(processMediaCard);
}

/**
 * Processes a single media card and adds appropriate status tag
 * @param {HTMLElement} card - The media card element
 */
function processMediaCard(card) {
    // Skip if already processed
    if (card.querySelector('.status-tag')) {
        return;
    }
    
    // Check if this is a TV show or movie card by looking at the data attributes
    const cardData = getCardData(card);
    
    if (!cardData) {
        return;
    }
    
    // Handle TV show status (episodeStatus)
    if (cardData.episodeStatus) {
        addTvShowStatusTag(card, cardData);
    } 
    // Handle movie status (downloadStatus)
    else if (cardData.downloadStatus) {
        addMovieStatusTag(card, cardData);
    }
    
    // Fix missing images
    const imgElement = card.querySelector('img');
    if (imgElement) {
        imgElement.onerror = function() {
            this.src = '/coverunavailable.png';
            // Remove the error handler to prevent potential loops
            this.onerror = null;
        };
        
        // Also check if the image is a placeholder from placeholder.com
        if (imgElement.src && imgElement.src.includes('placeholder.com')) {
            imgElement.src = '/coverunavailable.png';
        }
    }
}

/**
 * Extracts data from the media card element
 * @param {HTMLElement} card - The media card element
 * @returns {Object|null} - The extracted data or null if not found
 */
function getCardData(card) {
    // Try to get data from data attributes
    if (card.dataset.series) {
        try {
            return JSON.parse(card.dataset.series);
        } catch (e) {
            console.error('Error parsing series data:', e);
        }
    }
    
    if (card.dataset.movie) {
        try {
            return JSON.parse(card.dataset.movie);
        } catch (e) {
            console.error('Error parsing movie data:', e);
        }
    }
    
    // If no data attributes, try to find embedded script with data
    const scriptElement = card.querySelector('script[type="application/json"]');
    if (scriptElement) {
        try {
            return JSON.parse(scriptElement.textContent);
        } catch (e) {
            console.error('Error parsing embedded JSON:', e);
        }
    }
    
    // If we still don't have data, look for specific elements that might indicate status
    const title = card.querySelector('.media-title')?.textContent;
    const infoText = card.textContent;
    
    // Create a basic data object based on text content
    const data = { title: title };
    
    if (infoText.includes('Episode') || infoText.includes('Season')) {
        // This is likely a TV show
        if (infoText.includes('Missing Episodes')) {
            data.episodeStatus = 'MISSING_EPISODES';
        } else if (infoText.includes('All Episodes')) {
            data.episodeStatus = 'ALL_EPISODES';
        }
    } else {
        // This is likely a movie
        if (infoText.includes('Downloading')) {
            data.downloadStatus = 'DOWNLOADING';
            // Try to extract progress
            const progressMatch = infoText.match(/(\d+)%/);
            if (progressMatch) {
                data.downloadProgress = parseFloat(progressMatch[1]);
            }
        } else if (infoText.includes('Missing')) {
            data.downloadStatus = 'MISSING';
        } else if (infoText.includes('Available')) {
            data.downloadStatus = 'AVAILABLE';
        }
    }
    
    return Object.keys(data).length > 1 ? data : null;
}

/**
 * Adds a status tag to a TV show card
 * @param {HTMLElement} card - The media card element
 * @param {Object} data - The TV show data
 */
function addTvShowStatusTag(card, data) {
    const tagElement = document.createElement('div');
    tagElement.className = 'status-tag';
    
    if (data.episodeStatus === 'ALL_EPISODES') {
        tagElement.className += ' status-tag-all-episodes';
        tagElement.textContent = 'All Episodes';
    } else if (data.episodeStatus === 'MISSING_EPISODES') {
        tagElement.className += ' status-tag-missing-episodes';
        tagElement.textContent = 'Missing Episodes';
        
        // Add count if available
        if (data.missingEpisodeCount) {
            tagElement.textContent += ` (${data.missingEpisodeCount})`;
        }
    } else {
        return; // Don't add tag for unknown status
    }
    
    // Make sure the card has position relative for absolute positioning of the tag
    card.style.position = 'relative';
    
    // Add the tag to the card
    card.appendChild(tagElement);
}

/**
 * Adds a status tag to a movie card
 * @param {HTMLElement} card - The media card element
 * @param {Object} data - The movie data
 */
function addMovieStatusTag(card, data) {
    const tagElement = document.createElement('div');
    tagElement.className = 'status-tag';
    
    if (data.downloadStatus === 'MISSING') {
        tagElement.className += ' status-tag-missing';
        tagElement.textContent = 'Missing';
    } else if (data.downloadStatus === 'DOWNLOADING') {
        tagElement.className += ' status-tag-downloading';
        tagElement.textContent = 'Downloading';
        
        // Add progress bar if available
        if (data.downloadProgress) {
            // Add percentage to tag
            tagElement.textContent += ` ${Math.round(data.downloadProgress)}%`;
            
            // Create progress bar
            const progressBar = document.createElement('div');
            progressBar.className = 'download-progress';
            progressBar.style.width = `${data.downloadProgress}%`;
            card.appendChild(progressBar);
        }
    } else {
        return; // Don't add tag for available/unknown status
    }
    
    // Make sure the card has position relative for absolute positioning of the tag
    card.style.position = 'relative';
    
    // Add the tag to the card
    card.appendChild(tagElement);
}