<?php
// Configuration
define('DB_HOST', 'localhost');
define('DB_NAME', 'legendrecloud_lcmm');
define('DB_USER', 'legendrecloud_lcmmuser');
define('DB_PASS', 'Royal&Downloader*2025*');

// Connect to database
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// The password string directly
$password = 'X9k#vP2$mL8qZ3nT';
$hash = password_hash($password, PASSWORD_DEFAULT);

echo "Password: $password\n";
echo "Generated hash: $hash\n";
echo "Verification result: " . (password_verify($password, $hash) ? "true" : "false") . "\n\n";

// Update the password in the database
$stmt = $conn->prepare("UPDATE users SET password = ? WHERE email = 'cl@legendremedia.com'");
$stmt->bind_param("s", $hash);
$stmt->execute();
echo "Updated database with new hash\n";

// Verify the updated password
$stmt = $conn->prepare("SELECT password FROM users WHERE email = 'cl@legendremedia.com'");
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

echo "Retrieved hash from database: " . $user['password'] . "\n";
echo "Verification with database hash: " . (password_verify($password, $user['password']) ? "true" : "false") . "\n";

$conn->close();
?>