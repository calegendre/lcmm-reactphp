// LCMM enhancements

// Function to add logo to header
function addLogoToHeader() {
    // Find all header containers with the LCMM text
    const headerContainers = document.querySelectorAll('nav .flex .flex-shrink-0 h1, nav .flex .flex-shrink-0 span');
    
    // Also look for existing filter to remove
    const existingFilter = document.getElementById('user-filter');
    if (existingFilter && existingFilter.parentElement && !existingFilter.parentElement.classList.contains('activity-filters')) {
        const filterLabel = existingFilter.previousElementSibling;
        if (filterLabel && filterLabel.textContent.includes('Filter by user:')) {
            console.log("Removing old user filter");
            if (filterLabel.parentElement) {
                filterLabel.parentElement.removeChild(filterLabel);
            }
            existingFilter.parentElement.removeChild(existingFilter);
        }
    }
    
    headerContainers.forEach(container => {
        // Don't add logo if it already exists
        if (container.parentElement.querySelector('.logo-container')) {
            return;
        }
        
        // Get the text content before we modify
        const textContent = container.textContent || container.innerText;
        
        // Remove any existing elements in the parent
        const parent = container.parentElement;
        while (parent.firstChild) {
            parent.removeChild(parent.firstChild);
        }
        
        // Create a flexbox container
        parent.style.display = 'flex';
        parent.style.alignItems = 'center';
        parent.style.gap = '8px';
        
        // Add logo
        const logo = document.createElement('img');
        logo.src = '/logo.png';
        logo.alt = 'LCMM Logo';
        logo.style.height = '28px'; // Slightly smaller
        logo.style.marginRight = '8px';
        parent.appendChild(logo);
        
        // Re-add the text
        const text = document.createElement(container.tagName);
        text.className = container.className;
        text.innerHTML = textContent;
        text.style.margin = '0';
        text.style.padding = '0';
        parent.appendChild(text);
    });
}

// Function to add logo to login/signup page
function addLogoToLoginPage() {
    // More comprehensive selector for login forms
    const loginContainers = document.querySelectorAll('.login-container, .signup-container');
    
    loginContainers.forEach(container => {
        if (!container.querySelector('.login-logo')) {
            const form = container.querySelector('form');
            
            if (form) {
                const logo = document.createElement('img');
                logo.src = '/logo.png';
                logo.alt = 'LCMM Logo';
                logo.className = 'login-logo';
                
                container.insertBefore(logo, form);
                
                // Log for debugging
                console.log('Added logo to login/signup page');
            }
        }
    });
    
    // Fallback for login form without specific container class
    const standaloneForms = document.querySelectorAll('form.mt-8.space-y-6');
    
    standaloneForms.forEach(form => {
        if (!form.parentElement.querySelector('.login-logo')) {
            const logo = document.createElement('img');
            logo.src = '/logo.png';
            logo.alt = 'LCMM Logo';
            logo.className = 'login-logo';
            
            form.parentElement.insertBefore(logo, form);
            
            // Log for debugging
            console.log('Added logo to standalone login form');
        }
    });
}

// Function to handle missing cover images
function handleMissingImages() {
    const mediaImages = document.querySelectorAll('.media-card img, .cover-art img');
    
    mediaImages.forEach(img => {
        img.onerror = function() {
            this.src = '/coverunavailable.png';
            this.onerror = null; // Prevent infinite loop if placeholder is also missing
        };
    });
}

// Function to enhance activity logs with filtering
function enhanceActivityLogs() {
    // Try to identify the admin activity logs section
    const adminSection = findAdminSection();
    if (!adminSection) {
        // Will try again via the interval
        return;
    }
    
    // Look for any filter controls that might already exist (that we didn't create)
    const existingFilters = adminSection.querySelectorAll('select, label');
    existingFilters.forEach(filter => {
        // Only remove filters that are not in our custom filter container
        if (filter.parentElement && !filter.parentElement.classList.contains('activity-filters')) {
            // Check if it's a user filter
            if (filter.id === 'user-filter' || 
                (filter.textContent && filter.textContent.includes('Filter by user')) ||
                (filter.htmlFor && filter.htmlFor === 'user-filter')) {
                console.log("Removing existing filter:", filter);
                filter.parentElement.removeChild(filter);
            }
        }
    });
    
    // Check if we already added our filters
    if (adminSection.querySelector('.activity-filters')) {
        return;
    }
    
    console.log("Adding activity filters to admin section");
    
    // Find the table where logs are displayed
    const logTable = adminSection.querySelector('table');
    if (!logTable) {
        console.log("Could not find activity logs table");
        return;
    }
    
    // Create the filters container
    const filtersContainer = document.createElement('div');
    filtersContainer.className = 'activity-filters';
    filtersContainer.style.display = 'flex';
    filtersContainer.style.gap = '1rem';
    filtersContainer.style.marginBottom = '1rem';
    filtersContainer.style.flexWrap = 'wrap';
    
    // Create user filter
    const userFilter = createFilterElement('user-filter', 'All Users');
    
    // Create action filter
    const actionFilter = createFilterElement('action-filter', 'All Actions');
    
    // Create sort order dropdown
    const sortOrder = document.createElement('select');
    sortOrder.id = 'sort-order';
    applySelectStyles(sortOrder);
    sortOrder.innerHTML = `
        <option value="desc">Newest First</option>
        <option value="asc">Oldest First</option>
    `;
    
    // Create apply button
    const applyButton = document.createElement('button');
    applyButton.textContent = 'Apply Filters';
    applyButton.style.padding = '0.5rem 1rem';
    applyButton.style.borderRadius = '0.375rem';
    applyButton.style.backgroundColor = '#4f46e5';
    applyButton.style.borderColor = '#4338ca';
    applyButton.style.color = 'white';
    applyButton.style.cursor = 'pointer';
    applyButton.style.border = 'none';
    applyButton.style.fontWeight = 'bold';
    
    // Add hover effects
    applyButton.addEventListener('mouseover', function() {
        this.style.backgroundColor = '#4338ca';
    });
    
    applyButton.addEventListener('mouseout', function() {
        this.style.backgroundColor = '#4f46e5';
    });
    
    // Add click handler to fetch filtered logs
    applyButton.addEventListener('click', function() {
        const selectedUser = userFilter.value; 
        const selectedAction = actionFilter.value;
        const selectedOrder = sortOrder.value;
        
        console.log("Applying filters:", {
            user: selectedUser,
            action: selectedAction,
            order: selectedOrder
        });
        
        // Call the API with these filters
        fetchActivityLogs(selectedUser, selectedAction, selectedOrder);
    });
    
    // Populate filters with initial data
    populateFiltersFromTable(logTable, userFilter, actionFilter);
    
    // Add elements to filter container
    filtersContainer.appendChild(userFilter);
    filtersContainer.appendChild(actionFilter);
    filtersContainer.appendChild(sortOrder);
    filtersContainer.appendChild(applyButton);
    
    // Insert filters before the table
    logTable.parentNode.insertBefore(filtersContainer, logTable);
    
    // Store the table reference for updates
    window.activityLogTable = logTable;
    
    // Attempt an initial data fetch to ensure we have available actions
    const token = localStorage.getItem('lcmm_token');
    if (token) {
        fetch(`${window.LCMM_CONFIG.apiBaseUrl}/activity_logs.php`, {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.action_types && data.action_types.length > 0) {
                // Update the action filter dropdown
                actionFilter.innerHTML = '<option value="all">All Actions</option>';
                data.action_types.forEach(action => {
                    const option = document.createElement('option');
                    option.value = action;
                    option.textContent = action;
                    actionFilter.appendChild(option);
                });
            }
        })
        .catch(error => {
            console.error("Error fetching initial activity data:", error);
        });
    }
}

// Helper function to find the admin section containing activity logs
function findAdminSection() {
    // Try several methods to locate it
    
    // Method 1: Look for specific heading text
    const headings = Array.from(document.querySelectorAll('h1, h2, h3'));
    for (const heading of headings) {
        if (heading.textContent.includes('Activity Log')) {
            return heading.closest('div') || heading.parentElement;
        }
    }
    
    // Method 2: Look for activity logs container by ID
    const logsContainer = document.getElementById('activity-logs-container');
    if (logsContainer) {
        return logsContainer.parentElement || logsContainer;
    }
    
    // Method 3: Look for admin content section with a table
    const adminContent = document.querySelector('.admin-content');
    if (adminContent) {
        const table = adminContent.querySelector('table');
        if (table) {
            return adminContent;
        }
    }
    
    // Method 4: Look for any table in a section with "Admin" in the title
    const adminHeadings = Array.from(document.querySelectorAll('h1, h2, h3')).filter(
        h => h.textContent.includes('Admin')
    );
    
    for (const heading of adminHeadings) {
        const section = heading.closest('div') || heading.parentElement;
        if (section && section.querySelector('table')) {
            return section;
        }
    }
    
    return null;
}

// Helper function to create a styled select element
function createFilterElement(id, defaultOption) {
    const select = document.createElement('select');
    select.id = id;
    applySelectStyles(select);
    select.innerHTML = `<option value="all">${defaultOption}</option>`;
    return select;
}

// Helper function to apply common styles to select elements
function applySelectStyles(element) {
    element.style.padding = '0.5rem';
    element.style.borderRadius = '0.375rem';
    element.style.backgroundColor = '#2d2d2d';
    element.style.border = '1px solid #3e3e3e';
    element.style.color = 'white';
    element.style.minWidth = '150px';
}

// Helper function to populate filters from table data
function populateFiltersFromTable(table, userFilter, actionFilter) {
    if (!table) return;
    
    const tbody = table.querySelector('tbody');
    if (!tbody) return;
    
    const rows = tbody.querySelectorAll('tr');
    
    // Maps to track unique values
    const users = new Map();
    const actions = new Map();
    
    rows.forEach(row => {
        const cells = row.querySelectorAll('td');
        if (cells.length >= 5) {
            // Assuming format: Date | User | Action | Details | IP
            const user = cells[1]?.textContent?.trim();
            const action = cells[2]?.textContent?.trim();
            
            if (user && !users.has(user)) {
                users.set(user, true);
                const option = document.createElement('option');
                option.value = user;
                option.textContent = user;
                userFilter.appendChild(option);
            }
            
            if (action && !actions.has(action)) {
                actions.set(action, true);
                const option = document.createElement('option');
                option.value = action;
                option.textContent = action;
                actionFilter.appendChild(option);
            }
        }
    });
}

// Function to fetch activity logs with filters
function fetchActivityLogs(userId = 'all', actionType = 'all', sortOrder = 'desc') {
    // Get authentication token
    const token = localStorage.getItem('lcmm_token');
    
    if (!token) {
        console.error('No authentication token found');
        return;
    }
    
    // Show loading indicator
    const logTable = window.activityLogTable || document.querySelector('.admin-content table');
    if (logTable) {
        const loadingRow = document.createElement('tr');
        loadingRow.id = 'activity-logs-loading';
        loadingRow.innerHTML = `<td colspan="5" style="text-align: center; padding: 1rem;">Loading...</td>`;
        
        const tbody = logTable.querySelector('tbody');
        if (tbody) {
            // Clear existing rows
            tbody.innerHTML = '';
            tbody.appendChild(loadingRow);
        }
    }
    
    // Build query string
    let queryString = '?';
    if (userId !== 'all') {
        // Try to determine if it's an email or ID
        if (userId.includes('@')) {
            queryString += `email=${encodeURIComponent(userId)}&`;
        } else {
            queryString += `user_id=${userId}&`;
        }
    }
    
    if (actionType !== 'all') queryString += `action_type=${encodeURIComponent(actionType)}&`;
    queryString += `sort=${sortOrder}`;
    
    console.log(`Fetching logs with query: ${queryString}`);
    
    // Make API request
    fetch(`${window.LCMM_CONFIG.apiBaseUrl}/activity_logs.php${queryString}`, {
        method: 'GET',
        headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`HTTP error ${response.status}`);
        }
        return response.json();
    })
    .then(data => {
        console.log("Received activity logs data:", data);
        
        if (!data.logs) {
            console.error("No logs data in response");
            return;
        }
        
        // Update activity logs table
        updateActivityLogsTable(data.logs);
        
        // Update action filter if we have action types
        if (data.action_types && data.action_types.length > 0) {
            const actionFilter = document.getElementById('action-filter');
            if (actionFilter) {
                // Store current selection
                const currentSelection = actionFilter.value;
                
                // Keep the "All Actions" option
                actionFilter.innerHTML = '<option value="all">All Actions</option>';
                
                // Add options for each action type
                data.action_types.forEach(action => {
                    const option = document.createElement('option');
                    option.value = action;
                    option.textContent = action;
                    
                    // Restore selection if applicable
                    if (action === currentSelection || (currentSelection === 'all' && action === actionType)) {
                        option.selected = true;
                    }
                    
                    actionFilter.appendChild(option);
                });
            }
        }
    })
    .catch(error => {
        console.error('Error fetching activity logs:', error);
        
        // Show error in the table
        const logTable = window.activityLogTable || document.querySelector('.admin-content table');
        if (logTable) {
            const errorRow = document.createElement('tr');
            errorRow.innerHTML = `<td colspan="5" style="text-align: center; color: #ef4444; padding: 1rem;">Error: ${error.message || 'Failed to load activity logs'}</td>`;
            
            const tbody = logTable.querySelector('tbody');
            if (tbody) {
                // Remove loading indicator if present
                const loadingRow = tbody.querySelector('#activity-logs-loading');
                if (loadingRow) {
                    tbody.removeChild(loadingRow);
                }
                
                tbody.appendChild(errorRow);
            }
        }
    });
}

// Function to update activity logs table
function updateActivityLogsTable(logs) {
    // Try different ways to find the table
    const logTable = window.activityLogTable || 
                    document.querySelector('.admin-content table') || 
                    document.querySelector('table.admin-table');
    
    if (!logTable) {
        console.error("Couldn't find activity logs table for update");
        return;
    }
    
    const tbody = logTable.querySelector('tbody');
    if (!tbody) {
        console.error("Couldn't find table body in activity logs table");
        return;
    }
    
    // Clear existing rows
    tbody.innerHTML = '';
    
    if (logs.length === 0) {
        // Show no data message
        const noDataRow = document.createElement('tr');
        noDataRow.innerHTML = `<td colspan="5" style="text-align: center; padding: 1rem;">No activity logs found matching your filters</td>`;
        tbody.appendChild(noDataRow);
        return;
    }
    
    // Add new rows
    logs.forEach(log => {
        const row = document.createElement('tr');
        
        // Format the date
        const date = new Date(log.created_at);
        const formattedDate = date.toLocaleString();
        
        row.innerHTML = `
            <td>${formattedDate}</td>
            <td>${log.user_email || (log.user_id ? `User #${log.user_id}` : 'Unknown')}</td>
            <td>${log.action || 'Unknown'}</td>
            <td>${log.details || ''}</td>
            <td>${log.ip_address || ''}</td>
        `;
        
        tbody.appendChild(row);
    });
    
    console.log(`Updated activity logs table with ${logs.length} entries`);
}

// Function to make header sticky
function setupStickyHeader() {
    const header = document.querySelector('nav.bg-dark-100');
    
    if (header) {
        document.addEventListener('scroll', function() {
            if (window.scrollY > 10) {
                header.classList.add('scrolled');
            } else {
                header.classList.remove('scrolled');
            }
        });
    }
}

// Initialize all enhancements when the page loads
document.addEventListener('DOMContentLoaded', function() {
    runEnhancements();
    
    // Set interval to periodically check for dynamically loaded content
    setInterval(runEnhancements, 1000);
});

// Function to run all enhancements
function runEnhancements() {
    addLogoToHeader();
    addLogoToLoginPage();
    handleMissingImages();
    enhanceActivityLogs();
    setupStickyHeader();
}

// Also run these functions when route changes (SPA navigation)
const originalPushState = history.pushState;
history.pushState = function() {
    originalPushState.apply(this, arguments);
    setTimeout(runEnhancements, 100);
};