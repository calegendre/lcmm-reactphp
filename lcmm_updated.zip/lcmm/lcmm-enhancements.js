// LCMM enhancements

// Function to add logo to header
function addLogoToHeader() {
    // Find all header containers with the LCMM text
    const headerContainers = document.querySelectorAll('nav .flex .flex-shrink-0 h1, nav .flex .flex-shrink-0 span');
    
    headerContainers.forEach(container => {
        // Try to add the logo if it exists
        if (!container.parentElement.querySelector('.logo-container')) {
            const logoContainer = document.createElement('div');
            logoContainer.className = 'logo-container';
            
            const logo = document.createElement('img');
            logo.src = '/logo.png';
            logo.alt = 'LCMM Logo';
            
            logoContainer.appendChild(logo);
            container.parentElement.insertBefore(logoContainer, container);
        }
    });
}

// Function to add logo to login/signup page
function addLogoToLoginPage() {
    const loginForm = document.querySelector('.login-container form, .signup-container form');
    
    if (loginForm) {
        const logo = document.createElement('img');
        logo.src = '/logo.png';
        logo.alt = 'LCMM Logo';
        logo.className = 'login-logo';
        
        loginForm.parentElement.insertBefore(logo, loginForm);
    }
}

// Function to handle missing cover images
function handleMissingImages() {
    const mediaImages = document.querySelectorAll('.media-card img, .cover-art img');
    
    mediaImages.forEach(img => {
        img.onerror = function() {
            this.src = '/coverunavailable.png';
            this.onerror = null; // Prevent infinite loop if placeholder is also missing
        };
    });
}

// Function to enhance activity logs with filtering
function enhanceActivityLogs() {
    const activityLogsContainer = document.getElementById('activity-logs-container');
    
    if (activityLogsContainer) {
        // Check if filters already exist
        if (!document.querySelector('.activity-filters')) {
            // Create filter container
            const filterContainer = document.createElement('div');
            filterContainer.className = 'activity-filters';
            
            // User filter is already implemented, so we add action filter
            const actionFilter = document.createElement('select');
            actionFilter.id = 'action-filter';
            actionFilter.innerHTML = '<option value="all">All Actions</option>';
            
            // Get all unique actions from the table
            const actions = [];
            document.querySelectorAll('#activity-logs-container table tbody tr td:nth-child(3)').forEach(cell => {
                const action = cell.textContent.trim();
                if (!actions.includes(action)) {
                    actions.push(action);
                }
            });
            
            // Add options for each action
            actions.sort().forEach(action => {
                const option = document.createElement('option');
                option.value = action;
                option.textContent = action;
                actionFilter.appendChild(option);
            });
            
            // Sort order filter
            const sortOrder = document.createElement('select');
            sortOrder.id = 'sort-order';
            sortOrder.innerHTML = `
                <option value="desc">Newest First</option>
                <option value="asc">Oldest First</option>
            `;
            
            // Apply button
            const applyButton = document.createElement('button');
            applyButton.textContent = 'Apply Filters';
            applyButton.addEventListener('click', function() {
                const selectedAction = actionFilter.value;
                const selectedOrder = sortOrder.value;
                const selectedUser = document.getElementById('user-filter') ? document.getElementById('user-filter').value : 'all';
                
                // Call API with filters
                fetchActivityLogs(selectedUser, selectedAction, selectedOrder);
            });
            
            // Add to filter container
            filterContainer.appendChild(document.getElementById('user-filter') ? document.getElementById('user-filter').cloneNode(true) : document.createElement('div'));
            filterContainer.appendChild(actionFilter);
            filterContainer.appendChild(sortOrder);
            filterContainer.appendChild(applyButton);
            
            // Insert before table
            activityLogsContainer.insertBefore(filterContainer, activityLogsContainer.firstChild);
        }
    }
}

// Function to fetch activity logs with filters
function fetchActivityLogs(userId = 'all', actionType = 'all', sortOrder = 'desc') {
    // Get authentication token
    const token = localStorage.getItem('lcmm_token');
    
    if (!token) {
        console.error('No authentication token found');
        return;
    }
    
    // Build query string
    let queryString = '?';
    if (userId !== 'all') queryString += `user_id=${userId}&`;
    if (actionType !== 'all') queryString += `action_type=${actionType}&`;
    queryString += `sort=${sortOrder}`;
    
    // Make API request
    fetch(`${window.LCMM_CONFIG.apiBaseUrl}/activity_logs.php${queryString}`, {
        method: 'GET',
        headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
        }
    })
    .then(response => response.json())
    .then(data => {
        // Update activity logs table
        updateActivityLogsTable(data.logs);
        
        // Update action filter if we have action types
        if (data.action_types && data.action_types.length > 0) {
            const actionFilter = document.getElementById('action-filter');
            if (actionFilter) {
                // Keep the "All Actions" option
                actionFilter.innerHTML = '<option value="all">All Actions</option>';
                
                // Add options for each action type
                data.action_types.forEach(action => {
                    const option = document.createElement('option');
                    option.value = action;
                    option.textContent = action;
                    if (action === actionType) {
                        option.selected = true;
                    }
                    actionFilter.appendChild(option);
                });
            }
        }
    })
    .catch(error => {
        console.error('Error fetching activity logs:', error);
    });
}

// Function to update activity logs table
function updateActivityLogsTable(logs) {
    const tableBody = document.querySelector('#activity-logs-container table tbody');
    
    if (tableBody) {
        // Clear existing rows
        tableBody.innerHTML = '';
        
        // Add new rows
        logs.forEach(log => {
            const row = document.createElement('tr');
            
            row.innerHTML = `
                <td>${new Date(log.created_at).toLocaleString()}</td>
                <td>${log.user_email}</td>
                <td>${log.action}</td>
                <td>${log.details}</td>
                <td>${log.ip_address}</td>
            `;
            
            tableBody.appendChild(row);
        });
    }
}

// Function to make header sticky
function setupStickyHeader() {
    const header = document.querySelector('nav.bg-dark-100');
    
    if (header) {
        document.addEventListener('scroll', function() {
            if (window.scrollY > 10) {
                header.classList.add('scrolled');
            } else {
                header.classList.remove('scrolled');
            }
        });
    }
}

// Initialize all enhancements when the page loads
document.addEventListener('DOMContentLoaded', function() {
    addLogoToHeader();
    addLogoToLoginPage();
    handleMissingImages();
    enhanceActivityLogs();
    setupStickyHeader();
    
    // Also run these functions when route changes (SPA navigation)
    const originalPushState = history.pushState;
    history.pushState = function() {
        originalPushState.apply(this, arguments);
        setTimeout(() => {
            addLogoToHeader();
            addLogoToLoginPage();
            handleMissingImages();
            enhanceActivityLogs();
        }, 100);
    };
});

// Also check for dynamic content changes (React rendering)
window.addEventListener('load', function() {
    // Set up a mutation observer to detect when new content is added
    const observer = new MutationObserver(function(mutations) {
        mutations.forEach(function(mutation) {
            if (mutation.addedNodes.length > 0) {
                // New nodes were added, check if we need to enhance them
                addLogoToHeader();
                handleMissingImages();
                enhanceActivityLogs();
            }
        });
    });
    
    // Start observing the document body for changes
    observer.observe(document.body, { childList: true, subtree: true });
});