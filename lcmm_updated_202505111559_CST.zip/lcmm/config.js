// LCMM Configuration
window.LCMM_CONFIG = {
  apiBaseUrl: 'http://localhost:8080/api'
};