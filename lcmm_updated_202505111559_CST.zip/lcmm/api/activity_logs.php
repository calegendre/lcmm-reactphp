<?php
// activity_logs.php - API endpoint for viewing and filtering activity logs

// Enable error reporting during development
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Configuration
define('DB_HOST', 'localhost');
define('DB_NAME', 'legendrecloud_lcmm');
define('DB_USER', 'legendrecloud_lcmmuser');
define('DB_PASS', 'Royal&Downloader*2025*');
define('APP_SECRET', 'legendrecloud_secure_key_2025');

// Database connection function
function get_db_connection() {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    
    if ($conn->connect_error) {
        error_log("Connection failed: " . $conn->connect_error);
        return null;
    }
    
    return $conn;
}

// API response helpers
function send_json_response($data, $status_code = 200) {
    http_response_code($status_code);
    echo json_encode($data);
    exit();
}

function send_error($message, $status_code = 400) {
    send_json_response(['error' => $message], $status_code);
}

// JWT validation function
function validate_jwt($token) {
    $parts = explode('.', $token);
    
    if (count($parts) !== 3) {
        throw new Exception('Invalid token format');
    }
    
    list($header, $payload, $signature) = $parts;
    
    $valid_signature = base64_encode(hash_hmac('sha256', "$header.$payload", APP_SECRET, true));
    
    if ($signature !== $valid_signature) {
        throw new Exception('Invalid token signature');
    }
    
    $payload = json_decode(base64_decode($payload), true);
    
    if (!isset($payload['exp']) || $payload['exp'] < time()) {
        throw new Exception('Token has expired');
    }
    
    return $payload;
}

// Handle getting activity logs with filtering and sorting
function handle_activity_logs($user_id) {
    $conn = get_db_connection();
    if (!$conn) {
        send_error('Database connection error', 500);
    }
    
    // Get filter parameters
    $filter_user = isset($_GET['user_id']) ? intval($_GET['user_id']) : null;
    $filter_action = isset($_GET['action_type']) ? $_GET['action_type'] : null;
    $sort_order = isset($_GET['sort']) && strtolower($_GET['sort']) === 'asc' ? 'ASC' : 'DESC';
    
    // Build query with filters
    $sql = "
        SELECT a.*, u.email AS user_email 
        FROM activity_logs a
        JOIN users u ON a.user_id = u.id
        WHERE 1=1
    ";
    
    $params = [];
    $types = "";
    
    if ($filter_user !== null) {
        $sql .= " AND a.user_id = ?";
        $params[] = $filter_user;
        $types .= "i";
    }
    
    if ($filter_action !== null && $filter_action !== 'all') {
        $sql .= " AND a.action = ?";
        $params[] = $filter_action;
        $types .= "s";
    }
    
    $sql .= " ORDER BY a.created_at $sort_order LIMIT 500";
    
    if (count($params) > 0) {
        $stmt = $conn->prepare($sql);
        $stmt->bind_param($types, ...$params);
        $stmt->execute();
        $result = $stmt->get_result();
    } else {
        $result = $conn->query($sql);
    }
    
    if (!$result) {
        send_error('Error fetching activity logs: ' . $conn->error, 500);
    }
    
    $logs = [];
    while ($row = $result->fetch_assoc()) {
        $logs[] = $row;
    }
    
    // Get distinct action types for the filter dropdown
    $action_types = [];
    $action_result = $conn->query("SELECT DISTINCT action FROM activity_logs ORDER BY action");
    
    if ($action_result) {
        while ($row = $action_result->fetch_assoc()) {
            $action_types[] = $row['action'];
        }
    }
    
    // Log that admin viewed activity logs
    log_activity($user_id, 'view_logs', 'Viewed activity logs');
    
    send_json_response([
        'logs' => $logs,
        'action_types' => $action_types
    ]);
}

// Helper function to log activity
function log_activity($user_id, $action, $details = '', $ip_address = null) {
    if ($ip_address === null) {
        $ip_address = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    }
    
    $conn = get_db_connection();
    if (!$conn) {
        error_log('Unable to log activity: database connection error');
        return false;
    }
    
    $stmt = $conn->prepare("INSERT INTO activity_logs (user_id, action, details, ip_address) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("isss", $user_id, $action, $details, $ip_address);
    
    return $stmt->execute();
}

// Main code - Process the request
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Authorization, Content-Type');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Get JWT from authorization header
$headers = getallheaders();
$auth_header = $headers['Authorization'] ?? '';

if (!preg_match('/Bearer\s(\S+)/', $auth_header, $matches)) {
    send_error('Unauthorized: Missing or invalid token', 401);
}

$token = $matches[1];

try {
    $payload = validate_jwt($token);
    $user_id = $payload['user_id'];
    $role = $payload['role'];
    
    // Only admins can access activity logs
    if ($role !== 'admin') {
        send_error('Forbidden: Admin access required', 403);
    }
} catch (Exception $e) {
    send_error('Unauthorized: ' . $e->getMessage(), 401);
}

// Parse request
$request_method = $_SERVER['REQUEST_METHOD'];

// Only support GET requests
if ($request_method !== 'GET') {
    send_error('Method not allowed', 405);
}

handle_activity_logs($user_id);
?>