// LCMM Media Details Modal Script
// This adds detailed modals for TV shows and movies with search capabilities

document.addEventListener('DOMContentLoaded', function() {
    // Create modal container if it doesn't exist
    if (!document.getElementById('lcmm-modal-container')) {
        const modalContainer = document.createElement('div');
        modalContainer.id = 'lcmm-modal-container';
        document.body.appendChild(modalContainer);
    }
    
    // Setup click handlers for media cards
    setupMediaCardHandlers();
    
    // Set up observer for dynamically added content
    setupMutationObserver();
});

// Set up mutation observer to watch for new content
function setupMutationObserver() {
    const observer = new MutationObserver(function(mutations) {
        mutations.forEach(function(mutation) {
            if (mutation.addedNodes.length > 0) {
                // Look for media cards in added nodes
                mutation.addedNodes.forEach(function(node) {
                    if (node.nodeType === 1) { // Element node
                        if (node.classList && node.classList.contains('media-card')) {
                            setupMediaCardHandler(node);
                        } else if (node.querySelectorAll) {
                            const mediaCards = node.querySelectorAll('.media-card');
                            mediaCards.forEach(setupMediaCardHandler);
                        }
                    }
                });
            }
        });
    });
    
    // Start observing the document
    observer.observe(document.body, { childList: true, subtree: true });
}

// Setup click handlers for all media cards
function setupMediaCardHandlers() {
    const mediaCards = document.querySelectorAll('.media-card');
    mediaCards.forEach(setupMediaCardHandler);
}

// Setup click handler for a single media card
function setupMediaCardHandler(card) {
    // Skip if already processed
    if (card.getAttribute('data-modal-initialized')) {
        return;
    }
    
    // Mark as processed
    card.setAttribute('data-modal-initialized', 'true');
    
    // Make title clickable
    const title = card.querySelector('.media-title');
    if (title) {
        title.style.cursor = 'pointer';
        title.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            showMediaDetails(card);
        });
    }
    
    // Make image clickable
    const image = card.querySelector('img');
    if (image) {
        image.style.cursor = 'pointer';
        image.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            showMediaDetails(card);
        });
    }
}

// Show media details modal
async function showMediaDetails(card) {
    try {
        // Get media type and ID from card
        const mediaType = determineMediaType(card);
        const mediaId = getMediaId(card, mediaType);
        
        if (!mediaId) {
            console.error('Could not determine media ID');
            return;
        }
        
        // Show loading modal
        showLoadingModal();
        
        // Fetch details based on media type
        let details;
        if (mediaType === 'tv') {
            details = await fetchTvShowDetails(mediaId);
        } else if (mediaType === 'movie') {
            details = await fetchMovieDetails(mediaId);
        } else {
            console.error('Unknown media type:', mediaType);
            hideModal();
            return;
        }
        
        // Show details modal
        if (details) {
            if (mediaType === 'tv') {
                showTvShowModal(details);
            } else {
                showMovieModal(details);
            }
        } else {
            showErrorModal('Could not fetch media details');
        }
    } catch (error) {
        console.error('Error showing media details:', error);
        showErrorModal('Error fetching details: ' + error.message);
    }
}

// Determine if card is TV show or movie
function determineMediaType(card) {
    // Try to get from data attributes first
    if (card.hasAttribute('data-series')) {
        return 'tv';
    }
    if (card.hasAttribute('data-movie')) {
        return 'movie';
    }
    
    // Look for specific content
    const cardText = card.textContent || '';
    if (cardText.includes('Season') || cardText.includes('Episode')) {
        return 'tv';
    }
    
    // Check URL
    const currentUrl = window.location.href;
    if (currentUrl.includes('sonarr') || currentUrl.includes('tv')) {
        return 'tv';
    }
    if (currentUrl.includes('radarr') || currentUrl.includes('movies')) {
        return 'movie';
    }
    
    // Default to movie
    return 'movie';
}

// Get media ID from card
function getMediaId(card, mediaType) {
    // Try to get from data attributes first
    if (mediaType === 'tv' && card.hasAttribute('data-series')) {
        try {
            const seriesData = JSON.parse(card.getAttribute('data-series'));
            return seriesData.id;
        } catch (e) {
            console.error('Error parsing series data:', e);
        }
    }
    
    if (mediaType === 'movie' && card.hasAttribute('data-movie')) {
        try {
            const movieData = JSON.parse(card.getAttribute('data-movie'));
            return movieData.id;
        } catch (e) {
            console.error('Error parsing movie data:', e);
        }
    }
    
    // Try to find ID in other ways
    const linkEl = card.querySelector('a[href*="id="]');
    if (linkEl) {
        const href = linkEl.getAttribute('href');
        const match = href.match(/id=(\d+)/);
        if (match && match[1]) {
            return match[1];
        }
    }
    
    // Look for hidden input with ID
    const idInput = card.querySelector('input[type="hidden"][name="id"]');
    if (idInput) {
        return idInput.value;
    }
    
    // For embedded script data
    const scriptEl = card.querySelector('script[type="application/json"]');
    if (scriptEl) {
        try {
            const data = JSON.parse(scriptEl.textContent);
            return data.id;
        } catch (e) {
            console.error('Error parsing script data:', e);
        }
    }
    
    // If we still can't find it, try to find any numeric ID in the card's classes or attributes
    const classes = card.className.split(' ');
    for (const cls of classes) {
        if (/^(series|movie)-(\d+)$/.test(cls)) {
            return cls.split('-')[1];
        }
    }
    
    // Last resort: look for any data attribute with 'id' in the name
    for (const attr of card.attributes) {
        if (attr.name.includes('id') && !isNaN(attr.value)) {
            return attr.value;
        }
    }
    
    return null;
}

// Fetch TV show details from Sonarr API
async function fetchTvShowDetails(seriesId) {
    try {
        // Get auth token
        const token = localStorage.getItem('lcmm_token');
        if (!token) {
            throw new Error('No authentication token found');
        }
        
        // Fetch basic series info
        const seriesResponse = await fetch(`${window.LCMM_CONFIG.apiBaseUrl}/sonarr.php?action=series`, {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        
        if (!seriesResponse.ok) {
            throw new Error(`Failed to fetch series: ${seriesResponse.status}`);
        }
        
        const allSeries = await seriesResponse.json();
        const series = allSeries.find(s => s.id == seriesId);
        
        if (!series) {
            throw new Error(`Series with ID ${seriesId} not found`);
        }
        
        // Fetch episodes directly from Sonarr API using our proxy
        const episodesResponse = await fetch(`${window.LCMM_CONFIG.apiBaseUrl}/sonarr.php?action=episodes&seriesId=${seriesId}`, {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        
        if (!episodesResponse.ok) {
            throw new Error(`Failed to fetch episodes: ${episodesResponse.status}`);
        }
        
        const episodes = await episodesResponse.json();
        
        // Organize episodes by season
        const seasons = {};
        episodes.forEach(episode => {
            const seasonNumber = episode.seasonNumber;
            if (!seasons[seasonNumber]) {
                seasons[seasonNumber] = [];
            }
            seasons[seasonNumber].push(episode);
        });
        
        // Sort episodes within each season
        Object.keys(seasons).forEach(seasonNumber => {
            seasons[seasonNumber].sort((a, b) => a.episodeNumber - b.episodeNumber);
        });
        
        return {
            series,
            seasons
        };
    } catch (error) {
        console.error('Error fetching TV show details:', error);
        return null;
    }
}

// Fetch movie details from Radarr API
async function fetchMovieDetails(movieId) {
    try {
        // Get auth token
        const token = localStorage.getItem('lcmm_token');
        if (!token) {
            throw new Error('No authentication token found');
        }
        
        // Fetch movie info
        const moviesResponse = await fetch(`${window.LCMM_CONFIG.apiBaseUrl}/radarr.php?action=movies`, {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        
        if (!moviesResponse.ok) {
            throw new Error(`Failed to fetch movies: ${moviesResponse.status}`);
        }
        
        const allMovies = await moviesResponse.json();
        const movie = allMovies.find(m => m.id == movieId);
        
        if (!movie) {
            throw new Error(`Movie with ID ${movieId} not found`);
        }
        
        // Fetch queue information to see if movie is downloading
        const queueResponse = await fetch(`${window.LCMM_CONFIG.apiBaseUrl}/radarr.php?action=queue`, {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        
        let queueItem = null;
        if (queueResponse.ok) {
            const queue = await queueResponse.json();
            queueItem = queue.find(q => q.movieId == movieId);
        }
        
        return {
            movie,
            queueItem
        };
    } catch (error) {
        console.error('Error fetching movie details:', error);
        return null;
    }
}

// Show TV show modal
function showTvShowModal(data) {
    const { series, seasons } = data;
    
    const modalContent = document.createElement('div');
    modalContent.className = 'lcmm-modal-content';
    
    // Series poster and info
    const headerSection = document.createElement('div');
    headerSection.className = 'lcmm-modal-header';
    
    const posterContainer = document.createElement('div');
    posterContainer.className = 'lcmm-modal-poster';
    
    const poster = document.createElement('img');
    poster.src = series.images && series.images.length > 0 
        ? series.images.find(img => img.coverType === 'poster')?.url || '/coverunavailable.png'
        : '/coverunavailable.png';
    poster.alt = series.title;
    poster.onerror = function() {
        this.src = '/coverunavailable.png';
    };
    posterContainer.appendChild(poster);
    
    const infoContainer = document.createElement('div');
    infoContainer.className = 'lcmm-modal-info';
    
    const title = document.createElement('h2');
    title.textContent = series.title;
    
    const year = document.createElement('div');
    year.className = 'lcmm-modal-year';
    year.textContent = `${series.year || 'Unknown'} • ${series.status || 'Unknown Status'}`;
    
    const overview = document.createElement('div');
    overview.className = 'lcmm-modal-overview';
    overview.textContent = series.overview || 'No overview available';
    
    infoContainer.appendChild(title);
    infoContainer.appendChild(year);
    infoContainer.appendChild(overview);
    
    headerSection.appendChild(posterContainer);
    headerSection.appendChild(infoContainer);
    
    // Episodes section
    const episodesSection = document.createElement('div');
    episodesSection.className = 'lcmm-modal-episodes';
    
    const episodesTitle = document.createElement('h3');
    episodesTitle.textContent = 'Episodes';
    episodesSection.appendChild(episodesTitle);
    
    // Create accordion for seasons
    const seasonsContainer = document.createElement('div');
    seasonsContainer.className = 'lcmm-modal-seasons';
    
    // Sort seasons (excluding season 0)
    const sortedSeasons = Object.keys(seasons)
        .map(Number)
        .sort((a, b) => {
            // Put specials (season 0) at the end
            if (a === 0) return 1;
            if (b === 0) return -1;
            return b - a; // Latest seasons first
        });
    
    sortedSeasons.forEach(seasonNumber => {
        const seasonEpisodes = seasons[seasonNumber];
        if (!seasonEpisodes || seasonEpisodes.length === 0) return;
        
        const seasonContainer = document.createElement('div');
        seasonContainer.className = 'lcmm-modal-season';
        
        const seasonHeader = document.createElement('div');
        seasonHeader.className = 'lcmm-modal-season-header';
        seasonHeader.innerHTML = `
            <div class="lcmm-modal-season-title">
                ${seasonNumber === 0 ? 'Specials' : `Season ${seasonNumber}`}
                <span class="lcmm-modal-episode-count">${seasonEpisodes.length} episodes</span>
            </div>
            <div class="lcmm-modal-season-toggle">▼</div>
        `;
        
        // Toggle season expansion
        seasonHeader.addEventListener('click', function() {
            const isCollapsed = seasonContent.style.display === 'none';
            seasonContent.style.display = isCollapsed ? 'block' : 'none';
            seasonHeader.querySelector('.lcmm-modal-season-toggle').textContent = isCollapsed ? '▼' : '►';
        });
        
        const seasonContent = document.createElement('div');
        seasonContent.className = 'lcmm-modal-season-content';
        
        // Create episode list
        const episodeList = document.createElement('ul');
        episodeList.className = 'lcmm-modal-episode-list';
        
        seasonEpisodes.forEach(episode => {
            const episodeItem = document.createElement('li');
            episodeItem.className = 'lcmm-modal-episode-item';
            
            // Episode status
            let statusClass = '';
            let statusText = '';
            
            if (episode.hasFile) {
                statusClass = 'lcmm-episode-available';
                statusText = 'Available';
            } else {
                statusClass = 'lcmm-episode-missing';
                statusText = 'Missing';
            }
            
            episodeItem.classList.add(statusClass);
            
            // Episode info
            episodeItem.innerHTML = `
                <div class="lcmm-modal-episode-number">E${episode.episodeNumber}</div>
                <div class="lcmm-modal-episode-title">${episode.title}</div>
                <div class="lcmm-modal-episode-status">${statusText}</div>
                ${!episode.hasFile ? '<button class="lcmm-modal-search-button" data-episode-id="' + episode.id + '">Search</button>' : ''}
            `;
            
            // Add search functionality for missing episodes
            const searchButton = episodeItem.querySelector('.lcmm-modal-search-button');
            if (searchButton) {
                searchButton.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    searchForEpisode(episode.id);
                });
            }
            
            episodeList.appendChild(episodeItem);
        });
        
        seasonContent.appendChild(episodeList);
        
        // Expand only the latest season by default
        if (seasonNumber !== sortedSeasons[0] && seasonNumber !== 0) {
            seasonContent.style.display = 'none';
            seasonHeader.querySelector('.lcmm-modal-season-toggle').textContent = '►';
        }
        
        seasonContainer.appendChild(seasonHeader);
        seasonContainer.appendChild(seasonContent);
        seasonsContainer.appendChild(seasonContainer);
    });
    
    episodesSection.appendChild(seasonsContainer);
    
    // Assemble modal
    modalContent.appendChild(headerSection);
    modalContent.appendChild(episodesSection);
    
    // Close button
    const closeButton = document.createElement('button');
    closeButton.className = 'lcmm-modal-close-button';
    closeButton.textContent = '×';
    closeButton.addEventListener('click', hideModal);
    
    modalContent.appendChild(closeButton);
    
    // Show modal
    showModal(modalContent);
}

// Show movie modal
function showMovieModal(data) {
    const { movie, queueItem } = data;
    
    const modalContent = document.createElement('div');
    modalContent.className = 'lcmm-modal-content';
    
    // Movie poster and info
    const headerSection = document.createElement('div');
    headerSection.className = 'lcmm-modal-header';
    
    const posterContainer = document.createElement('div');
    posterContainer.className = 'lcmm-modal-poster';
    
    const poster = document.createElement('img');
    poster.src = movie.images && movie.images.length > 0 
        ? movie.images.find(img => img.coverType === 'poster')?.url || '/coverunavailable.png'
        : '/coverunavailable.png';
    poster.alt = movie.title;
    poster.onerror = function() {
        this.src = '/coverunavailable.png';
    };
    posterContainer.appendChild(poster);
    
    const infoContainer = document.createElement('div');
    infoContainer.className = 'lcmm-modal-info';
    
    const title = document.createElement('h2');
    title.textContent = movie.title;
    
    const year = document.createElement('div');
    year.className = 'lcmm-modal-year';
    const runtime = movie.runtime ? `${Math.floor(movie.runtime / 60)}h ${movie.runtime % 60}m` : '';
    year.textContent = `${movie.year || 'Unknown'} ${runtime ? '• ' + runtime : ''}`;
    
    const overview = document.createElement('div');
    overview.className = 'lcmm-modal-overview';
    overview.textContent = movie.overview || 'No overview available';
    
    infoContainer.appendChild(title);
    infoContainer.appendChild(year);
    infoContainer.appendChild(overview);
    
    headerSection.appendChild(posterContainer);
    headerSection.appendChild(infoContainer);
    
    // Status section
    const statusSection = document.createElement('div');
    statusSection.className = 'lcmm-modal-status';
    
    let statusHtml = '';
    
    if (movie.hasFile) {
        statusHtml = '<span class="lcmm-movie-available">Available</span>';
    } else if (queueItem) {
        const progress = queueItem.sizeleft && queueItem.size 
            ? Math.round(100 - ((queueItem.sizeleft / queueItem.size) * 100)) 
            : 0;
        
        statusHtml = `
            <span class="lcmm-movie-downloading">Downloading (${progress}%)</span>
            <div class="lcmm-download-progress-bar">
                <div class="lcmm-download-progress" style="width: ${progress}%"></div>
            </div>
        `;
    } else {
        statusHtml = `
            <span class="lcmm-movie-missing">Missing</span>
            <button class="lcmm-modal-search-button" data-movie-id="${movie.id}">Search</button>
        `;
    }
    
    statusSection.innerHTML = `
        <h3>Status</h3>
        <div class="lcmm-modal-status-content">
            ${statusHtml}
        </div>
    `;
    
    // Add search functionality for missing movies
    const searchButton = statusSection.querySelector('.lcmm-modal-search-button');
    if (searchButton) {
        searchButton.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            searchForMovie(movie.id);
        });
    }
    
    // Assemble modal
    modalContent.appendChild(headerSection);
    modalContent.appendChild(statusSection);
    
    // Close button
    const closeButton = document.createElement('button');
    closeButton.className = 'lcmm-modal-close-button';
    closeButton.textContent = '×';
    closeButton.addEventListener('click', hideModal);
    
    modalContent.appendChild(closeButton);
    
    // Show modal
    showModal(modalContent);
}

// Search for specific episode
async function searchForEpisode(episodeId) {
    try {
        const searchButton = document.querySelector(`.lcmm-modal-search-button[data-episode-id="${episodeId}"]`);
        if (searchButton) {
            searchButton.textContent = 'Searching...';
            searchButton.disabled = true;
        }
        
        // Get auth token
        const token = localStorage.getItem('lcmm_token');
        if (!token) {
            throw new Error('No authentication token found');
        }
        
        // Call the search API
        const response = await fetch(`${window.LCMM_CONFIG.apiBaseUrl}/sonarr.php?action=episode-search&episodeId=${episodeId}`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            }
        });
        
        if (!response.ok) {
            throw new Error(`Search request failed: ${response.status}`);
        }
        
        const result = await response.json();
        
        if (searchButton) {
            searchButton.textContent = 'Search Started';
            
            // Show success message
            const statusMessage = document.createElement('div');
            statusMessage.className = 'lcmm-search-success';
            statusMessage.textContent = 'Search started successfully';
            searchButton.parentNode.appendChild(statusMessage);
            
            // Remove message after 3 seconds
            setTimeout(() => {
                if (statusMessage.parentNode) {
                    statusMessage.parentNode.removeChild(statusMessage);
                }
            }, 3000);
        }
    } catch (error) {
        console.error('Error searching for episode:', error);
        
        const searchButton = document.querySelector(`.lcmm-modal-search-button[data-episode-id="${episodeId}"]`);
        if (searchButton) {
            searchButton.textContent = 'Search Failed';
            searchButton.disabled = false;
            
            // Show error message
            const errorMessage = document.createElement('div');
            errorMessage.className = 'lcmm-search-error';
            errorMessage.textContent = error.message;
            searchButton.parentNode.appendChild(errorMessage);
            
            // Remove message after 3 seconds
            setTimeout(() => {
                if (errorMessage.parentNode) {
                    errorMessage.parentNode.removeChild(errorMessage);
                }
                searchButton.textContent = 'Search';
            }, 3000);
        }
    }
}

// Search for movie
async function searchForMovie(movieId) {
    try {
        const searchButton = document.querySelector(`.lcmm-modal-search-button[data-movie-id="${movieId}"]`);
        if (searchButton) {
            searchButton.textContent = 'Searching...';
            searchButton.disabled = true;
        }
        
        // Get auth token
        const token = localStorage.getItem('lcmm_token');
        if (!token) {
            throw new Error('No authentication token found');
        }
        
        // Call the search API
        const response = await fetch(`${window.LCMM_CONFIG.apiBaseUrl}/radarr.php?action=movie-search&movieId=${movieId}`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            }
        });
        
        if (!response.ok) {
            throw new Error(`Search request failed: ${response.status}`);
        }
        
        const result = await response.json();
        
        if (searchButton) {
            searchButton.textContent = 'Search Started';
            
            // Show success message
            const statusMessage = document.createElement('div');
            statusMessage.className = 'lcmm-search-success';
            statusMessage.textContent = 'Search started successfully';
            searchButton.parentNode.appendChild(statusMessage);
            
            // Remove message after 3 seconds
            setTimeout(() => {
                if (statusMessage.parentNode) {
                    statusMessage.parentNode.removeChild(statusMessage);
                }
            }, 3000);
        }
    } catch (error) {
        console.error('Error searching for movie:', error);
        
        const searchButton = document.querySelector(`.lcmm-modal-search-button[data-movie-id="${movieId}"]`);
        if (searchButton) {
            searchButton.textContent = 'Search Failed';
            searchButton.disabled = false;
            
            // Show error message
            const errorMessage = document.createElement('div');
            errorMessage.className = 'lcmm-search-error';
            errorMessage.textContent = error.message;
            searchButton.parentNode.appendChild(errorMessage);
            
            // Remove message after 3 seconds
            setTimeout(() => {
                if (errorMessage.parentNode) {
                    errorMessage.parentNode.removeChild(errorMessage);
                }
                searchButton.textContent = 'Search';
            }, 3000);
        }
    }
}

// Show loading modal
function showLoadingModal() {
    const modalContent = document.createElement('div');
    modalContent.className = 'lcmm-modal-content lcmm-modal-loading';
    
    const loadingSpinner = document.createElement('div');
    loadingSpinner.className = 'lcmm-loading-spinner';
    
    const loadingText = document.createElement('div');
    loadingText.className = 'lcmm-loading-text';
    loadingText.textContent = 'Loading...';
    
    modalContent.appendChild(loadingSpinner);
    modalContent.appendChild(loadingText);
    
    showModal(modalContent);
}

// Show error modal
function showErrorModal(message) {
    const modalContent = document.createElement('div');
    modalContent.className = 'lcmm-modal-content lcmm-modal-error';
    
    const errorIcon = document.createElement('div');
    errorIcon.className = 'lcmm-error-icon';
    errorIcon.textContent = '!';
    
    const errorMessage = document.createElement('div');
    errorMessage.className = 'lcmm-error-message';
    errorMessage.textContent = message;
    
    const closeButton = document.createElement('button');
    closeButton.className = 'lcmm-modal-close-button';
    closeButton.textContent = 'Close';
    closeButton.addEventListener('click', hideModal);
    
    modalContent.appendChild(errorIcon);
    modalContent.appendChild(errorMessage);
    modalContent.appendChild(closeButton);
    
    showModal(modalContent);
}

// Show modal with content
function showModal(content) {
    const modalContainer = document.getElementById('lcmm-modal-container');
    if (!modalContainer) return;
    
    // Clear existing content
    modalContainer.innerHTML = '';
    
    // Create overlay
    const overlay = document.createElement('div');
    overlay.className = 'lcmm-modal-overlay';
    overlay.addEventListener('click', function(e) {
        if (e.target === overlay) {
            hideModal();
        }
    });
    
    // Add content to overlay
    overlay.appendChild(content);
    
    // Add overlay to container
    modalContainer.appendChild(overlay);
    
    // Add keyboard handler for escape key
    document.addEventListener('keydown', handleEscapeKey);
    
    // Show modal
    modalContainer.style.display = 'block';
    document.body.classList.add('lcmm-modal-open');
}

// Hide modal
function hideModal() {
    const modalContainer = document.getElementById('lcmm-modal-container');
    if (modalContainer) {
        modalContainer.style.display = 'none';
        modalContainer.innerHTML = '';
    }
    
    // Remove keyboard handler
    document.removeEventListener('keydown', handleEscapeKey);
    
    // Allow scrolling on body again
    document.body.classList.remove('lcmm-modal-open');
}

// Handle escape key to close modal
function handleEscapeKey(e) {
    if (e.key === 'Escape') {
        hideModal();
    }
}